### `helpers` namespace

This folder contains everything that's available via the [helpers] namespace, after initializing the library:

```js
const pgp = require('pg-promise')(/*initialization options*/);
const helpers = pgp.helpers; // `helpers` namespace
```

[helpers]:http://vitaly-t.github.io/pg-promise/helpers.html
